$('#sidebarleft, #sidebarright').stickySidebar({
	containerSelector: '.container',
	innerWrapperClass: 'sidebar__inner',
	topSpacing: 15,
	bottomSpacing: 15
});