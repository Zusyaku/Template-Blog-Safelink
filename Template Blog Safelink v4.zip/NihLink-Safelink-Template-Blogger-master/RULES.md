# RULES

## Do Not

- Do Not Remove My Footer Link
- Do Not Sell, Because It's Free

## Do

- Modify Without Remove My Footer Link