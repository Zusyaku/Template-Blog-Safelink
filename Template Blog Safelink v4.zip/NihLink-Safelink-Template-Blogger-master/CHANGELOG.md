# Changelog

## 2.6.5 - 16/04/2019
### Update
- ✅ Add startsWith Polyfill For IE 11 Compatible
- ✅ Fix Fetch BUG #2

## 2.5.4 - 10/04/2019
### Update
- ✅ Fix URL Start With "www"
- ✅ Add Countdown Toggle
- ✅ Change Structure Encoding
- ✅ Add ```autogenerate.js```

## 2.2.2 - 09/04/2019
### Update
- ✅ Add Countdown
- ✅ Fix Deep Extend jQuery

## 2.1.1 - 05/04/2019
### Update
- ✅ Add Random Post

## 2.0.1 - 04/04/2019
### Update
- ✅ Add Password System