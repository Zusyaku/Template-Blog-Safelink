Termia Kasih sudah berkunjung ke www.agieltriono.com

Template Dereloading adalah template safelink gratis yang di rilis di bawah Mit License.

PETUNJUK :

1. Anda tetap harus menyertakan credit link html atau credit pada css.

2. Anda berhak mendistribusikan kembali namun itu tergantung saya apakah anda layak atau tidak.

3. Di perbolehkan merubah kode secara kecil atau pun seluruh kode pada template namun dengan sepengetahuan saya.

3. Pada poin pertama anda boleh menghapus footer credit , namun anda tidak berhak merubah dan meningkatkan Lisensi walaupun anda sudah meminta izin. Termasuk lisensi yang terdapat pada CSS.


Agiel Triono - Situs Berbagi Ide dan Cerita